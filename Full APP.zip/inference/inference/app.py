from flask import Flask, render_template, request

from transformers import BigBirdPegasusForConditionalGeneration, AutoTokenizer, AutoModelForSequenceClassification

import torch
import torch.nn as nn
import numpy as np
import pickle


app = Flask(__name__)

model_name = "google/bigbird-pegasus-large-arxiv"
tokenizer1 = AutoTokenizer.from_pretrained(model_name)

model_name2 = "Hatoun/DistiBERT-finetuned-arxiv-multi-label"
tokenizer2 = AutoTokenizer.from_pretrained(model_name2)

# Load the multi-label binarizer
with open(r"multi-label-binarizer.pkl", "rb") as f:
    multilabel_binarizer = pickle.load(f)
    
device = "cuda" if torch.cuda.is_available() else "cpu"

model1 = BigBirdPegasusForConditionalGeneration.from_pretrained(model_name).to(device)

model2 = AutoModelForSequenceClassification.from_pretrained(model_name2)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/text-summarization', methods=["POST"])
def summarize():

    if request.method == "POST":

        inputtext = request.form["inputtext_"]

        input_text = "summarize: " + inputtext

        # Set the repetition penalty and length constraint
        repetition_penalty = 2.0
        length_constraint = 4096
        tokenized_text = tokenizer1.encode(input_text,truncation =True, padding ='longest', return_tensors='pt').to(device)
        summary_ = model1.generate(tokenized_text, repetition_penalty=repetition_penalty, max_length=length_constraint)
        summary = tokenizer1.decode(summary_[0])
        
        # Generate tags
        encoding = tokenizer2(summary, return_tensors="pt", padding=True, truncation=True).to(device)
        outputs = model2(**encoding)
        sigmoid = torch.nn.Sigmoid()
        probs = sigmoid(outputs.logits[0].cpu())
        preds = np.zeros(probs.shape)
        preds[np.where(probs>=0.3)] = 1

        # Convert predictions to categories
        tags = multilabel_binarizer.inverse_transform(preds.reshape(1,-1))


    return render_template("output.html", data = {"summary": summary,"tags": tags})

if __name__ == '__main__': 
    app.run()